package org.example;

import java.io.*;
import java.net.*;
import java.util.*;
import java.sql.*;

public class ProductServer {
    private static final int PORT = 56768;
    private static final List<Product> products = new ArrayList<>();
    private static final Map<String, String> users = new HashMap<>();

    private static final String URL = "jdbc:postgresql://localhost:3306";
    private static final String USER = "qwe";
    private static final String PASSWORD = "12345tyuiop";

    public static void main(String[] args) {
        /*Connection connection = null;

        try {
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Соединение с базой данных успешно.");

            String sql = "SELECT * FROM ";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                double price = resultSet.getDouble("price");
                System.out.println("ID: " + id + ", Name: " + name + ", Price: " + price);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }*/

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Сервер запущен на порту " + PORT);
            while (true) {
                Socket clientSocket = serverSocket.accept();
                new ClientHandler(clientSocket).start();
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    static class ClientHandler extends Thread {
        private Socket clientSocket;

        public ClientHandler(Socket socket) {
            this.clientSocket = socket;
        }

        public void run() {
            try (ObjectInputStream in = new ObjectInputStream(clientSocket.getInputStream());
                 ObjectOutputStream out = new ObjectOutputStream(clientSocket.getOutputStream())) {
                String command;
                while ((command = (String) in.readObject()) != null) {
                    switch (command) {
                        case "LOGIN":
                            handleLogin(in, out);
                            break;
                        case "REGISTER":
                            handleRegister(in, out);
                            break;
                        case "GET_PRODUCTS":
                            out.writeObject(products);
                            break;
                        case "ADD_PRODUCT":
                            Product product = (Product) in.readObject();
                            products.add(product);
                            out.writeObject("Товар добавлен");
                            break;
                        case "SEARCH":
                            String searchTerm = (String) in.readObject();
                            List<Product> searchResult = searchProducts(searchTerm);
                            out.writeObject(searchResult);
                            break;
                    }
                }
            }
            catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }

        private void handleLogin(ObjectInputStream in, ObjectOutputStream out) throws IOException, ClassNotFoundException {
            User user = (User) in.readObject();
            boolean success = users.containsKey(user.username) && users.get(user.username).equals(user.password);
            out.writeObject(success);
        }

        private void handleRegister(ObjectInputStream in, ObjectOutputStream out) throws IOException, ClassNotFoundException {
            User newUser = (User) in.readObject();
            if (users.containsKey(newUser.username)) {
                out.writeObject("Логин занят");
            }
            else {
                users.put(newUser.username, newUser.password);
                out.writeObject("Регистрация успешна");
            }
        }

        private List<Product> searchProducts(String searchTerm) {
            List<Product> result = new ArrayList<>();
            for (Product product : products) {
                if (product.name.toLowerCase().contains(searchTerm)) {
                    result.add(product);
                }
            }
            return result;
        }
    }
}