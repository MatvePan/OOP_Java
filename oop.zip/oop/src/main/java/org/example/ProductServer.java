package org.example;

import java.io.*;
import java.net.*;
import java.util.*;
import java.sql.*;

public class ProductServer {
    private static final int PORT = 56768;
    private static final List<Product> products = new ArrayList<>();
    private static final Map<String, String> users = new HashMap<>();

    private static final String URL = "127.0.0.1:3306";

    public static void main(String[] args) {

        try {
            String sql = "CREATE DATABASE base;\n" +
                    "USE base;\n" +
                    "CREATE TABLE users (\n" +
                    "                       username VARCHAR(50) NOT NULL UNIQUE,\n" +
                    "                       password VARCHAR(255) NOT NULL\n" +
                    ");\n" +
                    "CREATE TABLE products (\n" +
                    "                          id INT AUTO_INCREMENT PRIMARY KEY,\n" +
                    "                          name VARCHAR(100) NOT NULL,\n" +
                    "                          price DOUBLE NOT NULL\n" +
                    ");";

        }
        catch (Exception e) {
            e.printStackTrace();
        }

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Сервер запущен на порту " + PORT);
            while (true) {
                Socket clientSocket = serverSocket.accept();
                new ClientHandler(clientSocket).start();
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    static class ClientHandler extends Thread {
        private Socket clientSocket;

        public ClientHandler(Socket socket) {
            this.clientSocket = socket;
        }

        public void run() {
            try (ObjectInputStream in = new ObjectInputStream(clientSocket.getInputStream());
                 ObjectOutputStream out = new ObjectOutputStream(clientSocket.getOutputStream())) {
                String command;
                while ((command = (String) in.readObject()) != null) {
                    switch (command) {
                        case "LOGIN":
                            handleLogin(in, out);
                            break;
                        case "REGISTER":
                            handleRegister(in, out);
                            break;
                        case "GET_PRODUCTS":
                            out.writeObject(products);
                            break;
                        case "ADD_PRODUCT":
                            Product product = (Product) in.readObject();
                            products.add(product);
                            out.writeObject("Товар добавлен");
                            break;
                        case "SEARCH":
                            String searchTerm = (String) in.readObject();
                            List<Product> searchResult = searchProducts(searchTerm);
                            out.writeObject(searchResult);
                            break;
                        case "DELETE_PRODUCT":
                            String productNameToDelete = (String) in.readObject(); // Читаем название товара
                            boolean removed = products.removeIf(p -> p.getName().equals(productNameToDelete)); // Удаляем по названию
                            if (removed) {
                                out.writeObject("Товар удален");
                            } else {
                                out.writeObject("Товар не найден");
                            }
                            break;
                        case "EDIT_PRODUCT":
                            Product updatedProduct = (Product) in.readObject(); // Читаем обновленный товар
                            boolean foundToEdit = false;
                            for (int i = 0; i < products.size(); i++) {
                                if (products.get(i).getName().equals(updatedProduct.getName())) { // Ищем по названию
                                    products.set(i, updatedProduct);
                                    out.writeObject("Товар обновлен");
                                    foundToEdit = true;
                                    break;
                                }
                            }
                            if (!foundToEdit) {
                                out.writeObject("Товар не найден для обновления");
                            }
                            break;
                    }
                }
            }
            catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }

        private void handleLogin(ObjectInputStream in, ObjectOutputStream out) throws IOException, ClassNotFoundException {
            User user = (User) in.readObject();
            boolean success = users.containsKey(user.username) && users.get(user.username).equals(user.password);
            out.writeObject(success);
        }

        private void handleRegister(ObjectInputStream in, ObjectOutputStream out) throws IOException, ClassNotFoundException {
            User newUser = (User) in.readObject();
            if (users.containsKey(newUser.username)) {
                out.writeObject("Логин занят");
            }
            else {
                users.put(newUser.username, newUser.password);
                out.writeObject("Регистрация успешна");
            }
        }

        private List<Product> searchProducts(String searchTerm) {
            List<Product> result = new ArrayList<>();
            for (Product product : products) {
                if (product.name.toLowerCase().contains(searchTerm)) {
                    result.add(product);
                }
            }
            return result;
        }
    }
}