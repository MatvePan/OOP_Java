package org.example;

import java.io.Serializable;

public class User implements Serializable {
    private static final long serialVersionUID = 1L;
    String username;
    String password;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }
}