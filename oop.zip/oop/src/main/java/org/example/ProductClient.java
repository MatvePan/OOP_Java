package org.example;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.*;
import java.util.List;

public class ProductClient extends JFrame {
    private final String SERVER_ADDRESS = "localhost";
    private final int SERVER_PORT = 56768;
    private boolean isLoggedIn = false;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JTextArea productArea;
    private JTextField productField;
    private JTextField priceField;
    private JTextField searchField;
    private JButton addButton;
    private JButton deleteButton;
    private JButton editButton;

    public ProductClient() {
        initUI();
    }

    private void initUI() {
        setTitle("Клиент");
        setSize(1024, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        JPanel authPanel = new JPanel();
        usernameField = new JTextField(10);
        passwordField = new JPasswordField(10);
        JButton loginButton = new JButton("Войти");
        JButton registerButton = new JButton("Зарегистрироваться");
        authPanel.add(new JLabel("Логин:"));
        authPanel.add(usernameField);
        authPanel.add(new JLabel("Пароль:"));
        authPanel.add(passwordField);
        authPanel.add(loginButton);
        authPanel.add(registerButton);
        add(authPanel, BorderLayout.NORTH);
        productArea = new JTextArea();
        productArea.setEditable(false);
        add(new JScrollPane(productArea), BorderLayout.CENTER);
        JPanel productPanel = new JPanel();
        searchField = new JTextField(10);
        JButton searchButton = new JButton("Поиск/Список");
        productField = new JTextField(10);
        priceField = new JTextField(10);
        addButton = new JButton("Добавить товар");
        deleteButton = new JButton("Удалить товар");
        editButton = new JButton("Изменить товар");
        addButton.setEnabled(false);
        deleteButton.setEnabled(false);
        editButton.setEnabled(false);
        productPanel.add(new JLabel("Поиск"));
        productPanel.add(searchField);
        productPanel.add(searchButton);
        productPanel.add(new JLabel("Товар:"));
        productPanel.add(productField);
        productPanel.add(new JLabel("Стоимость:"));
        productPanel.add(priceField);
        productPanel.add(addButton);
        productPanel.add(deleteButton);
        productPanel.add(editButton);
        add(productPanel, BorderLayout.SOUTH);

        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                login();
            }
        });

        registerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                register();
            }
        });

        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                addProduct();
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deleteProduct();
            }
        });

        editButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                editProduct();
            }
        });

        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                searchProducts();
            }
        });
    }

    private void login() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());
        try {
            Socket socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
            ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
            User user = new User(username, password);
            out.writeObject("LOGIN");
            out.writeObject(user);
            isLoggedIn = (boolean) in.readObject();
            if (isLoggedIn) {
                JOptionPane.showMessageDialog(null, "Авторизовано");
                usernameField.setEnabled(false);
                passwordField.setEnabled(false);
                loadProducts();
                addButton.setEnabled(true);
                deleteButton.setEnabled(true);
                editButton.setEnabled(true);
            }
            else {
                JOptionPane.showMessageDialog(null, "Неверный вход");
            }
            socket.close();
        }
        catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void register() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());
        try {
            Socket socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
            ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
            User user = new User(username, password);
            out.writeObject("REGISTER");
            out.writeObject(user);
            String response = (String) in.readObject();
            JOptionPane.showMessageDialog(null, response);
            socket.close();
        }
        catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void loadProducts() {
        try {
            Socket socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
            ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
            out.writeObject("GET_PRODUCTS");
            List<Product> products = (List<Product>) in.readObject();
            productArea.setText("");
            for (Product product : products) {
                productArea.append(product.toString() + "\n");
            }
            socket.close();
        }
        catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void searchProducts() {
        String searchTerm = searchField.getText().toLowerCase().trim();
        try {
            Socket socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
            ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
            out.writeObject("SEARCH");
            out.writeObject(searchTerm);
            List<Product> products = (List<Product>) in.readObject();
            productArea.setText("");
            for (Product product : products) {
                productArea.append(product.toString() + "\n");
            }
            socket.close();
        }
        catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void addProduct() {
        String productName = productField.getText();
        double productPrice;
        try {
            productPrice = Double.parseDouble(priceField.getText());
            Product product = new Product(productName, productPrice);
            Socket socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
            ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
            out.writeObject("ADD_PRODUCT");
            out.writeObject(product);
            loadProducts();
            productField.setText("");
            priceField.setText("");
            socket.close();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Неверная стоимость");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void deleteProduct() {
        String productName = productField.getText();
        try {
            Socket socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
            ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
            out.writeObject("DELETE_PRODUCT");
            out.writeObject(productName);
            loadProducts();
            productField.setText("");
            socket.close();
            JOptionPane.showMessageDialog(null, "Товар удалён");
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void editProduct() {
        String productName = productField.getText();
        double productPrice;
        try {
            productPrice = Double.parseDouble(priceField.getText());
            Product product = new Product(productName, productPrice);
            Socket socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
            ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
            out.writeObject("EDIT_PRODUCT");
            out.writeObject(product);
            loadProducts();
            productField.setText("");
            priceField.setText("");
            socket.close();
            JOptionPane.showMessageDialog(null, "Товар изменён");
        }
        catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Неверная стоимость");
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ProductClient client = new ProductClient();
            client.setVisible(true);
        });
    }
}